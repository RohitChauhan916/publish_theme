<?php get_header();?>

        <section class="blog_section_title">
            <h1 class="page-title">404</h1>
        </section>

    <section class="blog_scection_content">
        <div class="container">
            <div class="row">
                <div class="col s12">
                    <h3 class="not_found">Page Not Found</h3>
                </div>   
            </div>
        </div>
    </section>

<?php get_footer();?>